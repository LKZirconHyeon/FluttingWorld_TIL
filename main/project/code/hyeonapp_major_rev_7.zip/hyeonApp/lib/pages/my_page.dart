import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class MyPage extends StatefulWidget {
  const MyPage({Key? key}) : super(key: key);

  @override
  State<MyPage> createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  String username = '';
  String emailTag = '';
  String? photoUrl;

  @override
  void initState() {
    super.initState();
    _loadUserProfile();
  }

  Future<void> _loadUserProfile() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final snapshot = await FirebaseDatabase.instance
        .ref('users/$sanitizedEmail/username')
        .get();

    setState(() {
      username = snapshot.value?.toString() ?? '알 수 없음';
      emailTag = user.email!.split('@')[0];
      photoUrl = user.photoURL; // 아직 설정되지 않았을 수도 있음
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 50,
            backgroundImage: photoUrl != null
                ? NetworkImage(photoUrl!)
                : const AssetImage('assets/default_profile.png')
            as ImageProvider,
          ),
          const SizedBox(height: 16),
          Text(
            username,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            '#$emailTag',
            style: const TextStyle(fontSize: 16, color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
