import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class ContentViewPage extends StatelessWidget {
  final Map<String, dynamic> journal;
  final String journalId;

  const ContentViewPage({
    Key? key,
    required this.journal,
    required this.journalId,
  }) : super(key: key);

  Future<void> _deleteJournal(BuildContext context) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('로그인이 필요합니다.');

      final sanitizedEmail = user.email!.replaceAll('.', '_');
      await FirebaseDatabase.instance
          .ref('users/$sanitizedEmail/journals/$journalId')
          .remove();

      // ✅ 삭제 성공 알림은 pop 이후로 넘기지 말고 상위에서 처리하게!
      Navigator.pop(context, true); // ← 상위 화면에서 true 수신 → 새로고침 유도

    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('삭제 실패: $e')),
        );
      }
    }
  }



  @override
  Widget build(BuildContext context) {
    final List<dynamic> bodyImages = journal['bodyImages'] ?? [];
    final formattedDate = formatDateRange(journal['date'] ?? '');


    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E1),
      appBar: AppBar(
        title: const Text('여행일지 상세보기'),
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('삭제 확인'),
                  content: const Text('정말 삭제하시겠습니까?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: const Text('취소'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: const Text('삭제'),
                    ),
                  ],
                ),
              );

              if (confirmed == true) {
                await _deleteJournal(context);
              }
            },

          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 대표 이미지
            if (journal['mainImageUrl'] != null &&
                journal['mainImageUrl'] != '')
              Center(
                child: Image.file(
                  File(journal['mainImageUrl']),
                  width: MediaQuery.of(context).size.width * 0.5,
                  height: MediaQuery.of(context).size.width * 0.5,
                  fit: BoxFit.cover,
                ),
              ),
            const SizedBox(height: 16),

            // 제목
            Text(
              journal['title'] ?? '제목 없음',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // 날짜
            Text(
              formattedDate,
              style: const TextStyle(fontSize: 16, color: Colors.grey),
            ),
            const SizedBox(height: 16),

            // 내용
            Text(
              journal['content'] ?? '내용 없음',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 16),

            // 본문 이미지
            if (bodyImages.isNotEmpty)
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: bodyImages.map((path) {
                  return Image.file(
                    File(path),
                    width: 100,
                    height: 100,
                    fit: BoxFit.cover,
                  );
                }).toList(),
              ),
          ],
        ),
      ),
    );
  }
  String formatDateRange(String rawDate) {
    if (rawDate.contains('~')) {
      final parts = rawDate.split('~');
      final start = DateTime.tryParse(parts[0].trim());
      final end = DateTime.tryParse(parts[1].trim());

      if (start != null && end != null) {
        return '${DateFormat('yyyy년 MM월 dd일').format(start)} ~ ${DateFormat('yyyy년 MM월 dd일').format(end)}';
      }
    } else {
      final date = DateTime.tryParse(rawDate);
      if (date != null) {
        return DateFormat('yyyy년 MM월 dd일').format(date);
      }
    }
    return '날짜 오류';
  }

}
