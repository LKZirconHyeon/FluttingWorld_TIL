import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class ContentViewPage extends StatelessWidget {
  final Map<String, dynamic> journal;
  final String journalId;

  const ContentViewPage({
    Key? key,
    required this.journal,
    required this.journalId,
  }) : super(key: key);

  Future<void> _deleteJournal(BuildContext context) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('로그인이 필요합니다.');

      final sanitizedEmail = user.email!.replaceAll('.', '_');
      await FirebaseDatabase.instance
          .ref('users/$sanitizedEmail/journals/$journalId')
          .remove();

      // pop 먼저 호출 (뒤로가기)
      Navigator.pop(context);

      // pop 직전 context와 ScaffoldMessenger를 위해 따로 context 사용
      Future.delayed(Duration.zero, () {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('삭제되었습니다.')),
        );
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('삭제 실패: $e')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    final List<dynamic> bodyImages = journal['bodyImages'] ?? [];
    final formattedDate = DateFormat('yyyy년 MM월 dd일').format(
      DateTime.tryParse(journal['date'] ?? '') ?? DateTime.now(),
    );

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E1),
      appBar: AppBar(
        title: const Text('여행일지 상세보기'),
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('삭제 확인'),
                  content: const Text('정말 삭제하시겠습니까?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('취소'),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _deleteJournal(context);
                      },
                      child: const Text('삭제'),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 대표 이미지
            if (journal['mainImageUrl'] != null &&
                journal['mainImageUrl'] != '')
              Center(
                child: Image.file(
                  File(journal['mainImageUrl']),
                  width: MediaQuery.of(context).size.width * 0.5,
                  height: MediaQuery.of(context).size.width * 0.5,
                  fit: BoxFit.cover,
                ),
              ),
            const SizedBox(height: 16),

            // 제목
            Text(
              journal['title'] ?? '제목 없음',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // 날짜
            Text(
              formattedDate,
              style: const TextStyle(fontSize: 16, color: Colors.grey),
            ),
            const SizedBox(height: 16),

            // 내용
            Text(
              journal['content'] ?? '내용 없음',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 16),

            // 본문 이미지
            if (bodyImages.isNotEmpty)
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: bodyImages.map((path) {
                  return Image.file(
                    File(path),
                    width: 100,
                    height: 100,
                    fit: BoxFit.cover,
                  );
                }).toList(),
              ),
          ],
        ),
      ),
    );
  }
}
