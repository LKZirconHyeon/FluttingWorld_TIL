import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_home.dart';
import 'register_page.dart';
import 'find_password_page.dart';
import 'pages/add_journal.dart';
import 'pages/list_page.dart';
import 'pages/map_page.dart';
import 'pages/my_page.dart';
import 'utils/app_colors.dart';

final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  final prefs = await SharedPreferences.getInstance();
  final isDarkMode = prefs.getBool('isDarkMode') ?? false;
  themeNotifier.value = isDarkMode ? ThemeMode.dark : ThemeMode.light;

  runApp(const TravelPlannerApp());
}

class TravelPlannerApp extends StatelessWidget {
  const TravelPlannerApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, mode, _) {
        return MaterialApp(
          title: '여행 플래너',
          themeMode: mode,
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.light(
              primary: AppColors.primaryGreen,
              onPrimary: AppColors.onPrimary,
              background: AppColors.lightBackground,
              onBackground: AppColors.onBackground,
              surfaceVariant: AppColors.lightCard,
              onSurfaceVariant: AppColors.onBackground,
              outline: Colors.grey,
            ),
            scaffoldBackgroundColor: AppColors.lightBackground,
            appBarTheme: const AppBarTheme(
              backgroundColor: AppColors.primaryGreen,
              titleTextStyle: TextStyle(
                color: AppColors.onPrimary,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              centerTitle: true,
              elevation: 0,
              toolbarHeight: 48,
            ),
            floatingActionButtonTheme: const FloatingActionButtonThemeData(
              backgroundColor: AppColors.primaryGreen,
              foregroundColor: AppColors.onPrimary,
            ),
            bottomNavigationBarTheme: BottomNavigationBarThemeData(
              backgroundColor: AppColors.bottomBarBackground,
              selectedItemColor: AppColors.primaryGreen,
              unselectedItemColor: Colors.grey[600],
            ),
            textTheme: const TextTheme(
              bodyLarge: TextStyle(color: AppColors.onBackground),
              bodyMedium: TextStyle(color: Colors.black54),
            ),
            snackBarTheme: SnackBarThemeData(
              backgroundColor: AppColors.snackBarLightBackground,
              contentTextStyle: TextStyle(color: AppColors.snackBarLightText),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              behavior: SnackBarBehavior.floating,
              elevation: 0,
            ),
          ),

          darkTheme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.dark(
              primary: AppColors.darkGreen,
              onPrimary: AppColors.snackBarDarkText,
              background: AppColors.darkBackground,
              onBackground: AppColors.onDarkBackground,
              surfaceVariant: AppColors.darkCard,
              onSurfaceVariant: AppColors.onDarkBackground,
              outline: Colors.grey,
            ),
            scaffoldBackgroundColor: AppColors.darkBackground,
            appBarTheme: const AppBarTheme(
              backgroundColor: AppColors.darkGreen,
              titleTextStyle: TextStyle(
                color: AppColors.onPrimary,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              centerTitle: true,
              elevation: 0,
              toolbarHeight: 48,
            ),

            floatingActionButtonTheme: const FloatingActionButtonThemeData(
              backgroundColor: AppColors.darkGreen,
              foregroundColor: AppColors.onPrimary,
            ),

            bottomNavigationBarTheme: BottomNavigationBarThemeData(
              backgroundColor: AppColors.darkBottomBarBackground,
              selectedItemColor: AppColors.darkGreen,
              unselectedItemColor: Colors.white60,
              selectedIconTheme: const IconThemeData(color: AppColors.darkGreen),   // ✅ 추가
              unselectedIconTheme: const IconThemeData(color: Colors.white60),      // ✅ 추가
            ),

            iconTheme: const IconThemeData(color: Colors.white70), // ✅ 일반 아이콘

            textTheme: const TextTheme(
              bodyLarge: TextStyle(color: AppColors.onDarkBackground),
              bodyMedium: TextStyle(color: Colors.white60),
              bodySmall: TextStyle(color: Colors.white60),          // ✅ 추가
              labelLarge: TextStyle(color: Colors.white70),         // ✅ 선택적
              titleMedium: TextStyle(color: Colors.white),          // ✅ 선택적
            ),

            snackBarTheme: SnackBarThemeData(
              backgroundColor: AppColors.snackBarDarkBackground,
              contentTextStyle: const TextStyle(color: AppColors.snackBarDarkText),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              behavior: SnackBarBehavior.floating,
              elevation: 0,
            ),
          ),

          initialRoute: '/',
          routes: {
            '/': (context) => LoginScreen(),
            '/register': (context) => const RegisterPage(),
            '/find_password': (context) => const FindPasswordPage(),
            '/home': (context) => const HomeScreen(),
          },
        );
      },
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  String _userDisplay = '사용자';
  bool _refreshRequested = false;

  @override
  void initState() {
    super.initState();
    _loadUserInfo();
  }

  Future<void> _loadUserInfo() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final sanitizedEmail = user.email!.replaceAll('.', '_');
      final snapshot = await FirebaseDatabase.instance
          .ref('users/$sanitizedEmail/username')
          .get();
      if (snapshot.exists) {
        setState(() {
          _userDisplay = snapshot.value.toString();
        });
      }
    }
  }

  String _getTopTitle() {
    switch (_selectedIndex) {
      case 0:
        return '$_userDisplay의 여행일지';
      case 1:
        return '지도';
      case 2:
        return '마이페이지';
      default:
        return '';
    }
  }

  void _onAddPressed() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => JournalWriteScreen()),
    );

    if (result == true) {
      setState(() {
        _refreshRequested = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      ListPage(refreshOnReturn: _refreshRequested),
      const MapPage(),
      const MyPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(_getTopTitle()),
        actions: _selectedIndex == 2
            ? [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('로그아웃'),
                  content: const Text('로그아웃 하시겠습니까?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: const Text('취소'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: const Text('로그아웃'),
                    ),
                  ],
                ),
              );

              if (confirmed == true) {
                await FirebaseAuth.instance.signOut();
                if (context.mounted) {
                  Navigator.pushReplacementNamed(context, '/');
                }
              }
            },
          ),
        ]
            : null,
      ),
      body: pages[_selectedIndex],
      floatingActionButton: _selectedIndex == 0
          ? FloatingActionButton(
        onPressed: _onAddPressed,
        child: const Icon(Icons.add),
      )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
            if (index == 0) _refreshRequested = false;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.list),
            label: '리스트',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.map),
            label: '지도',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: '마이페이지',
          ),
        ],
      ),
    );
  }
}
