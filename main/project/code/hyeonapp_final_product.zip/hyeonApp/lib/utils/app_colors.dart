import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryGreen = Color(0xFF4DB6AC); // 라이트 테마용 포인트 초록
  static const Color darkGreen = Color(0xFF00BFA5); // 다크 테마용 포인트 초록

  static const Color lightBackground = Color(0xFFFFF8E1); // 밝은 배경
  static const Color darkBackground = Color(0xFF0D1B2A); // 어두운 배경

  static const Color onPrimary = Colors.white; // AppBar 텍스트 등
  static const Color onBackground = Colors.black87; // 밝은 배경의 기본 텍스트
  static const Color onDarkBackground = Colors.white70; // 어두운 배경의 기본 텍스트

  static const Color bottomBarBackground = Color(0xFFE0E0E0); // 밝은 하단바
  static const Color darkBottomBarBackground = Color(0xFF1A2633); // 어두운 하단바

  static const Color lightCard = Colors.white; // 카드 배경 (밝음)
  static const Color darkCard = Color(0xFF1C2B3A); // 카드 배경 (어두움)

  // ✅ SnackBar 전용 색상 (명시적 고정)
  static const Color snackBarLightBackground = Color(0xFF000000); // 검정
  static const Color snackBarLightText = Color(0xFFFFFFFF);       // 흰색

  static const Color snackBarDarkBackground = Color(0xFFFFFFFF);  // 흰색
  static const Color snackBarDarkText = Color(0xFF000000);        // 검정
}

