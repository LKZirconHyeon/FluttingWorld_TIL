import 'package:flutter/material.dart';
import '../utils/app_colors.dart';

void showCustomSnackBar(BuildContext context, String message) {
  final isDark = Theme.of(context).brightness == Brightness.dark;

  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        message,
        style: TextStyle(
          color: isDark
              ? AppColors.snackBarDarkText
              : AppColors.snackBarLightText,
        ),
      ),
      backgroundColor: isDark
          ? AppColors.snackBarDarkBackground
          : AppColors.snackBarLightBackground,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      duration: const Duration(seconds: 2),
    ),
  );
}



