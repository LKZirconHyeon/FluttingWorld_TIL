import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:intl/intl.dart';
import 'content_view.dart';
import '../utils/app_colors.dart';

class ListPage extends StatefulWidget {
  final bool refreshOnReturn;

  const ListPage({Key? key, this.refreshOnReturn = false}) : super(key: key);

  @override
  State<ListPage> createState() => _ListPageState();
}

class _ListPageState extends State<ListPage> {
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  List<Map<String, dynamic>> _journals = [];

  @override
  void initState() {
    super.initState();
    _fetchJournals();
  }

  @override
  void didUpdateWidget(covariant ListPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.refreshOnReturn && !oldWidget.refreshOnReturn) {
      _fetchJournals();
    }
  }

  String formatDateRange(String rawDate) {
    if (rawDate.contains('~')) {
      final parts = rawDate.split('~');
      final start = DateTime.tryParse(parts[0].trim());
      final end = DateTime.tryParse(parts[1].trim());
      if (start != null && end != null) {
        return '${DateFormat('yyyy년 MM월 dd일').format(start)} ~ ${DateFormat('yyyy년 MM월 dd일').format(end)}';
      }
    } else {
      final date = DateTime.tryParse(rawDate);
      if (date != null) {
        return DateFormat('yyyy년 MM월 dd일').format(date);
      }
    }
    return '날짜 오류';
  }

  Future<void> _fetchJournals() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');

    final snapshot = await _database.child('users/$sanitizedEmail/journals').get();
    List<Map<String, dynamic>> temp = [];
    if (snapshot.exists) {
      final data = snapshot.value as Map<dynamic, dynamic>;
      data.forEach((key, value) {
        final item = Map<String, dynamic>.from(value);
        item['journalId'] = key;
        item['author'] = sanitizedEmail;
        temp.add(item);
      });
    }

    final sharedFromOthers = await _fetchSharedJournalsFromAllUsers();
    sharedFromOthers.removeWhere((j) => j['author'] == sanitizedEmail);

    if (!mounted) return;
    setState(() {
      _journals = [...temp, ...sharedFromOthers];
    });
  }

  Future<List<Map<String, dynamic>>> _fetchSharedJournalsFromAllUsers() async {
    final rootSnapshot = await _database.child('users').get();
    List<Map<String, dynamic>> shared = [];

    if (rootSnapshot.exists) {
      final allUsers = Map<String, dynamic>.from(rootSnapshot.value as Map);
      allUsers.forEach((userId, userData) {
        if (userData is Map && userData['journals'] != null) {
          final journals = Map<String, dynamic>.from(userData['journals']);
          journals.forEach((journalId, value) {
            final journal = Map<String, dynamic>.from(value);
            if (journal['shared'] == true) {
              journal['journalId'] = journalId;
              journal['author'] = userId;
              shared.add(journal);
            }
          });
        }
      });
    }

    return shared;
  }

  void _showSnack(String message) {
    if (!mounted) return;

    final isDark = Theme.of(context).brightness == Brightness.dark;

    final backgroundColor = isDark
        ? AppColors.snackBarDarkBackground   // 흰색
        : AppColors.snackBarLightBackground; // 검정색

    final textColor = isDark
        ? AppColors.snackBarDarkText         // 검정
        : AppColors.snackBarLightText;       // 흰색

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(color: textColor),
        ),
        backgroundColor: backgroundColor,
        elevation: 0, // ✅ 그림자 제거
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.only(bottom: 80, left: 16, right: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }


  Widget _buildJournalCard(BuildContext context, Map<String, dynamic> journal) {
    final dateString = journal['date'] ?? '';
    final formattedDate = formatDateRange(dateString);
    final imagePath = journal['mainImageUrl'];

    return GestureDetector(
      onTap: () async {
        final result = await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ContentViewPage(
              journal: journal,
              journalId: journal['journalId'],
            ),
          ),
        );

        if (result != null) {
          await _fetchJournals();
          switch (result) {
            case 'share_enabled':
              _showSnack('공유가 활성화되었습니다.');
              break;
            case 'share_cancelled':
              _showSnack('공유가 중지되었습니다.');
              break;
            case true:
              _showSnack('삭제가 완료되었습니다.');
              break;
          }
        }
      },
      child: Card(
        color: Theme.of(context).cardColor, // ✅ 다크모드 대응
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      journal['title'] ?? '제목 없음',
                      style: Theme.of(context).textTheme.bodyLarge!.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      formattedDate,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              if (imagePath != null && imagePath.isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.file(
                    File(imagePath),
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                  ),
                )
              else
                Container(
                  width: 60,
                  height: 60,
                  color: Theme.of(context).dividerColor.withOpacity(0.1),
                  child: Icon(Icons.image, color: Theme.of(context).iconTheme.color),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final myJournals = _journals.where((j) => j['shared'] != true).toList();
    final sharedJournals = _journals.where((j) => j['shared'] == true).toList();

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: ListView(
        children: [
          const SizedBox(height: 20),
          Center(
            child: Text("내 여행일지", style: Theme.of(context).textTheme.bodyLarge!.copyWith(fontSize: 20, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 10),
          ...myJournals.map((j) => _buildJournalCard(context, j)),

          const SizedBox(height: 30),
          Center(
            child: Text("공유된 여행일지", style: Theme.of(context).textTheme.bodyLarge!.copyWith(fontSize: 20, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 10),
          ...sharedJournals.map((j) => _buildJournalCard(context, j)),
        ],
      ),
    );
  }
}
