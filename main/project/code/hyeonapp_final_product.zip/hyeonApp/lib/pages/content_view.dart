import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import '../utils/app_colors.dart';

class ContentViewPage extends StatefulWidget {
  final Map<String, dynamic> journal;
  final String journalId;

  const ContentViewPage({
    Key? key,
    required this.journal,
    required this.journalId,
  }) : super(key: key);

  @override
  State<ContentViewPage> createState() => _ContentViewPageState();
}

class _ContentViewPageState extends State<ContentViewPage> {
  String? displayAuthor;
  bool isOwner = false;

  @override
  void initState() {
    super.initState();
    _loadAuthorInfo();
  }

  Future<void> _loadAuthorInfo() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    final currentSanitized = currentUser?.email?.replaceAll('.', '_') ?? '';
    final journalAuthor = widget.journal['author']?.toString() ?? '';

    final snapshot = await FirebaseDatabase.instance
        .ref('users/$journalAuthor/username')
        .get();

    final nickname = snapshot.exists ? snapshot.value.toString() : journalAuthor;

    setState(() {
      isOwner = journalAuthor == currentSanitized;
      displayAuthor = isOwner ? '$nickname (본인)' : nickname;
    });
  }

  Future<void> _deleteJournal(BuildContext context) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('로그인이 필요합니다.');

      final sanitizedEmail = user.email!.replaceAll('.', '_');
      await FirebaseDatabase.instance
          .ref('users/$sanitizedEmail/journals/${widget.journalId}')
          .remove();

      Navigator.pop(context, 'deleted');
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('삭제 실패: $e')),
        );
      }
    }
  }

  Future<void> _toggleShareStatus() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final journalRef = FirebaseDatabase.instance
        .ref('users/$sanitizedEmail/journals/${widget.journalId}');

    final currentShared = widget.journal['shared'] == true;
    await journalRef.update({'shared': !currentShared});

    setState(() {
      widget.journal['shared'] = !currentShared;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final List<dynamic> bodyImages = widget.journal['bodyImages'] ?? [];
    final formattedDate = formatDateRange(widget.journal['date'] ?? '');

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.lightBackground,
      appBar: AppBar(
        backgroundColor: theme.appBarTheme.backgroundColor,
        iconTheme: IconThemeData(color: theme.colorScheme.onPrimary),
        title: Text(
          '여행일지 상세보기',
          style: theme.appBarTheme.titleTextStyle,
        ),
        actions: [
          if (isOwner)
            IconButton(
              icon: Icon(
                widget.journal['shared'] == true ? Icons.share : Icons.share_outlined,
                color: theme.colorScheme.onPrimary,
              ),
              onPressed: () async {
                await _toggleShareStatus();
                if (mounted) {
                  final result = widget.journal['shared'] == true
                      ? 'share_enabled'
                      : 'share_cancelled';
                  Navigator.pop(context, result);
                }
              },
              tooltip: widget.journal['shared'] == true ? '공유 중지' : '공유하기',
            ),
          if (isOwner)
            IconButton(
              icon: const Icon(Icons.delete),
              color: theme.colorScheme.onPrimary,
              onPressed: () async {
                final confirmed = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('삭제 확인'),
                    content: const Text('정말 삭제하시겠습니까?'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('취소'),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('삭제'),
                      ),
                    ],
                  ),
                );
                if (confirmed == true) {
                  await _deleteJournal(context);
                }
              },
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (widget.journal['mainImageUrl'] != null &&
                widget.journal['mainImageUrl'] != '')
              Center(
                child: Image.file(
                  File(widget.journal['mainImageUrl']),
                  width: MediaQuery.of(context).size.width * 0.5,
                  height: MediaQuery.of(context).size.width * 0.5,
                  fit: BoxFit.cover,
                ),
              ),
            const SizedBox(height: 16),
            Text(
              widget.journal['title'] ?? '제목 없음',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              formattedDate,
              style: theme.textTheme.bodyMedium?.copyWith(color: Colors.grey),
            ),
            const SizedBox(height: 8),
            if (displayAuthor != null)
              Text(
                '작성자: $displayAuthor',
                style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey),
              ),
            const SizedBox(height: 16),
            Text(
              widget.journal['content'] ?? '내용 없음',
              style: theme.textTheme.bodyLarge,
            ),
            const SizedBox(height: 16),
            if (bodyImages.isNotEmpty)
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: bodyImages.map((path) {
                  return Image.file(
                    File(path),
                    width: 100,
                    height: 100,
                    fit: BoxFit.cover,
                  );
                }).toList(),
              ),
          ],
        ),
      ),
    );
  }

  String formatDateRange(String rawDate) {
    if (rawDate.contains('~')) {
      final parts = rawDate.split('~');
      final start = DateTime.tryParse(parts[0].trim());
      final end = DateTime.tryParse(parts[1].trim());

      if (start != null && end != null) {
        return '${DateFormat('yyyy년 MM월 dd일').format(start)} ~ ${DateFormat('yyyy년 MM월 dd일').format(end)}';
      }
    } else {
      final date = DateTime.tryParse(rawDate);
      if (date != null) {
        return DateFormat('yyyy년 MM월 dd일').format(date);
      }
    }
    return '날짜 오류';
  }
}
