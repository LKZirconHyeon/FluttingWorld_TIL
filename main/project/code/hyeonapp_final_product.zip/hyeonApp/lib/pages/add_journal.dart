import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../utils/app_colors.dart';

class JournalWriteScreen extends StatefulWidget {
  @override
  State<JournalWriteScreen> createState() => _JournalWriteScreenState();
}

class _JournalWriteScreenState extends State<JournalWriteScreen> {
  String? mainImagePath;
  List<String> bodyImages = [];
  bool isRange = false;
  DateTime? selectedStartDate;
  DateTime? selectedEndDate;

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();

  Future<void> _pickMainImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        mainImagePath = pickedFile.path;
      });
    }
  }

  Future<void> _pickBodyImages() async {
    final picker = ImagePicker();
    final pickedFiles = await picker.pickMultiImage();
    if (pickedFiles.isNotEmpty) {
      setState(() {
        bodyImages.addAll(pickedFiles.map((file) => file.path));
      });
    }
  }

  Future<void> _pickDate() async {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final themedPicker = (Widget child) => Theme(
      data: Theme.of(context).copyWith(
        colorScheme: isDark
            ? ColorScheme.dark(
          primary: AppColors.darkGreen,
          onPrimary: AppColors.snackBarDarkText,
          onSurface: AppColors.onDarkBackground,
        )
            : ColorScheme.light(
          primary: AppColors.primaryGreen,
          onPrimary: AppColors.snackBarLightText,
          onSurface: AppColors.onBackground,
        ),
      ),
      child: child,
    );

    if (isRange) {
      final pickedRange = await showDateRangePicker(
        context: context,
        firstDate: DateTime(2000),
        lastDate: DateTime(2100),
        builder: (context, child) => themedPicker(child!),
      );
      if (pickedRange != null) {
        setState(() {
          selectedStartDate = pickedRange.start;
          selectedEndDate = pickedRange.end;
        });
      }
    } else {
      final pickedDate = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2000),
        lastDate: DateTime(2100),
        builder: (context, child) => themedPicker(child!),
      );
      if (pickedDate != null) {
        setState(() {
          selectedStartDate = pickedDate;
          selectedEndDate = null;
        });
      }
    }
  }

  Future<void> _saveJournal() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('로그인이 필요합니다.');

      if (_titleController.text.trim().isEmpty ||
          _contentController.text.trim().isEmpty ||
          mainImagePath == null ||
          selectedStartDate == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('모든 필드를 채워주세요.')),
        );
        return;
      }

      final sanitizedEmail = user.email!.replaceAll('.', '_');
      final journalId = DateTime.now().millisecondsSinceEpoch.toString();

      await FirebaseDatabase.instance
          .ref('users/$sanitizedEmail/journals/$journalId')
          .set({
        'title': _titleController.text.trim(),
        'content': _contentController.text.trim(),
        'date': isRange
            ? '${selectedStartDate!.toIso8601String()} ~ ${selectedEndDate!.toIso8601String()}'
            : selectedStartDate!.toIso8601String(),
        'mainImageUrl': mainImagePath ?? '',
        'bodyImages': bodyImages,
        'author': sanitizedEmail,
      });

      Navigator.pop(context, true);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('저장 실패: $e')),
      );
    }
  }

  Future<bool> _onWillPop() async {
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('작성 취소'),
        content: const Text('작성을 취소하고 나가시겠습니까?\n(저장되지 않습니다.)'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('아니오')),
          TextButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('네')),
        ],
      ),
    );
    return shouldExit ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: colorScheme.background,
        appBar: AppBar(
          title: const Text('여행일지 작성'),
          backgroundColor: colorScheme.primary,
          foregroundColor: colorScheme.onPrimary,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () async {
              final shouldExit = await _onWillPop();
              if (shouldExit) Navigator.of(context).pop();
            },
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.5,
                  height: MediaQuery.of(context).size.width * 0.5,
                  decoration: BoxDecoration(
                    color: colorScheme.surfaceVariant,
                    border: Border.all(color: colorScheme.outline),
                  ),
                  child: mainImagePath == null
                      ? Center(child: Text('대표 이미지 미리보기', style: TextStyle(color: colorScheme.onSurfaceVariant)))
                      : Image.file(File(mainImagePath!), fit: BoxFit.cover),
                ),
              ),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: _pickMainImage,
                child: const Text('대표 이미지 첨부'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: '제목',
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: colorScheme.onBackground),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Text('여행 날짜', style: TextStyle(color: colorScheme.onBackground)),
                  const SizedBox(width: 8),
                  Switch(
                    value: isRange,
                    onChanged: (val) {
                      setState(() {
                        isRange = val;
                        selectedStartDate = null;
                        selectedEndDate = null;
                      });
                    },
                  ),
                  Text(isRange ? '기간' : '단일 날짜', style: TextStyle(color: colorScheme.onBackground)),
                ],
              ),
              FilledButton(onPressed: _pickDate, child: const Text('날짜 선택')),
              if (selectedStartDate != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(
                    isRange && selectedEndDate != null
                        ? '${_formatDate(selectedStartDate!)} ~ ${_formatDate(selectedEndDate!)}'
                        : _formatDate(selectedStartDate!),
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: colorScheme.onBackground),
                  ),
                ),
              const SizedBox(height: 16),
              TextField(
                controller: _contentController,
                maxLines: 8,
                decoration: const InputDecoration(
                  labelText: '내용',
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: colorScheme.onBackground),
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: _pickBodyImages, child: const Text('본문 이미지 첨부')),
              if (bodyImages.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Wrap(
                    spacing: 8,
                    children: bodyImages
                        .map((path) => Image.file(File(path), width: 80, height: 80, fit: BoxFit.cover))
                        .toList(),
                  ),
                ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _saveJournal,
                style: FilledButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                ),
                child: const Text('저장'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.year}년 ${date.month.toString().padLeft(2, '0')}월 ${date.day.toString().padLeft(2, '0')}일';
  }
}
