import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

import '../utils/app_colors.dart';
import '../utils/snackbar_helper.dart'; // 🔹 경로는 프로젝트 구조에 맞게 수정하세요

class PersonalEditPage extends StatefulWidget {
  const PersonalEditPage({Key? key}) : super(key: key);

  @override
  State<PersonalEditPage> createState() => _PersonalEditPageState();
}

class _PersonalEditPageState extends State<PersonalEditPage> {
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();

  String emailTag = '';
  String? photoUrl;
  File? _newImageFile;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final snapshot = await FirebaseDatabase.instance
        .ref('users/$sanitizedEmail')
        .get();

    setState(() {
      _nameController.text =
          snapshot.child("username").value?.toString() ?? '';
      _passwordController.text =
          snapshot.child("password").value?.toString() ?? '';
      emailTag = user.email!.split('@')[0];
      photoUrl = snapshot.child("photoUrl").value?.toString();
    });
  }

  Future<void> _pickProfileImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);

    if (picked != null) {
      setState(() {
        _newImageFile = File(picked.path);
      });
    }
  }

  Future<void> _saveChanges() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final ref = FirebaseDatabase.instance.ref('users/$sanitizedEmail');

    String? uploadedImageUrl = photoUrl;
    final newPassword = _passwordController.text.trim();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      if (_newImageFile != null) {
        final storageRef = FirebaseStorage.instance
            .ref()
            .child('profile_images/$sanitizedEmail.png');

        final uploadTask = storageRef.putFile(_newImageFile!);
        await uploadTask.timeout(
          const Duration(seconds: 15),
          onTimeout: () => throw Exception("⏰ 이미지 업로드 시간 초과"),
        );

        uploadedImageUrl = await storageRef.getDownloadURL();
      }

      if (newPassword.isNotEmpty) {
        final cred = EmailAuthProvider.credential(
          email: user.email!,
          password: newPassword,
        );

        try {
          await user.reauthenticateWithCredential(cred);
        } catch (_) {
          // 과제 목적: 현재 비밀번호 인증 생략
        }

        await user.updatePassword(newPassword);
      }

      await ref.update({
        "username": _nameController.text.trim(),
        "password": newPassword,
        "photoUrl": uploadedImageUrl,
      });

      await FirebaseAuth.instance.currentUser?.reload();

      setState(() {
        _newImageFile = null;
        photoUrl = uploadedImageUrl;
      });

      if (Navigator.canPop(context)) Navigator.pop(context); // 로딩창 종료
      showCustomSnackBar(context, "정보가 저장되었습니다");

      Future.delayed(const Duration(seconds: 1), () {
        Navigator.pop(context); // 페이지 종료
      });
    } catch (e) {
      if (Navigator.canPop(context)) Navigator.pop(context); // 로딩창 종료
      showCustomSnackBar(context, "저장 실패: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final defaultProfileUrl =
        'https://firebasestorage.googleapis.com/v0/b/hyeonproject-9cd52.firebasestorage.app/o/default_profile.png?alt=media';

    return Scaffold(
      backgroundColor: isDark
          ? AppColors.darkBackground
          : AppColors.lightBackground,
      appBar: AppBar(
        title: const Text('개인정보 수정'),
        backgroundColor: isDark ? AppColors.darkGreen : AppColors.primaryGreen,
        foregroundColor: AppColors.onPrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Center(
              child: GestureDetector(
                onTap: _pickProfileImage,
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: _newImageFile != null
                      ? FileImage(_newImageFile!)
                      : (photoUrl != null && photoUrl!.isNotEmpty
                      ? NetworkImage(photoUrl!)
                      : NetworkImage(defaultProfileUrl)) as ImageProvider,
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: "닉네임",
                border: const OutlineInputBorder(),
                filled: true,
                fillColor: isDark ? Colors.black12 : Colors.white,
              ),
              style: TextStyle(
                color: isDark ? Colors.white : Colors.black87,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              readOnly: true,
              onTap: () {
                showCustomSnackBar(context, "계정 태그는 변경할 수 없습니다.");
              },
              decoration: InputDecoration(
                labelText: "계정 태그",
                hintText: "#$emailTag",
                border: const OutlineInputBorder(),
                filled: true,
                fillColor: isDark ? Colors.black12 : Colors.white,
              ),
              style: TextStyle(
                color: isDark ? Colors.white : Colors.black87,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: "비밀번호",
                border: const OutlineInputBorder(),
                filled: true,
                fillColor: isDark ? Colors.black12 : Colors.white,
              ),
              style: TextStyle(
                color: isDark ? Colors.white : Colors.black87,
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _saveChanges,
              icon: const Icon(Icons.save),
              label: const Text("저장하기"),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor:
                isDark ? AppColors.darkGreen : AppColors.primaryGreen,
                foregroundColor: AppColors.onPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }

}
