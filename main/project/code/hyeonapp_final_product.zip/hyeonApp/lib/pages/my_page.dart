import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:hyeonapp/pages/personal_edit.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../main_home.dart'; // ValueNotifier<ThemeMode> themeNotifier가 선언된 곳

class MyPage extends StatefulWidget {
  const MyPage({Key? key}) : super(key: key);

  @override
  State<MyPage> createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  String username = '';
  String emailTag = '';
  String? photoUrl;
  int journalCount = 0;
  int sharedCount = 0;
  bool isDarkMode = false;

  @override
  void initState() {
    super.initState();
    _loadUserProfile();
    _loadJournalCount();
    _loadThemePreference();
  }

  Future<void> _loadThemePreference() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('appTheme');
    setState(() {
      isDarkMode = saved == 'dark';
    });
  }

  Future<void> _toggleTheme(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      isDarkMode = value;
      themeNotifier.value = isDarkMode ? ThemeMode.dark : ThemeMode.light;
    });
    await prefs.setString('appTheme', isDarkMode ? 'dark' : 'light');
  }

  Future<void> _loadUserProfile() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final snapshot = await FirebaseDatabase.instance.ref('users/$sanitizedEmail').get();

    setState(() {
      username = snapshot.child('username').value?.toString() ?? '알 수 없음';
      photoUrl = snapshot.child('photoUrl').value?.toString();
      emailTag = user.email!.split('@')[0];
    });
  }

  Future<void> _loadJournalCount() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final snapshot = await FirebaseDatabase.instance.ref('users/$sanitizedEmail/journals').get();

    int total = 0;
    int shared = 0;

    if (snapshot.exists) {
      for (final journal in snapshot.children) {
        final data = journal.value as Map<dynamic, dynamic>;
        total++;
        if (data['shared'] == true) shared++;
      }
    }

    setState(() {
      journalCount = total;
      sharedCount = shared;
    });
  }

  @override
  Widget build(BuildContext context) {
    final ImageProvider imageProvider = (photoUrl != null &&
        photoUrl!.isNotEmpty &&
        (photoUrl!.startsWith('http') || photoUrl!.startsWith('https')))
        ? NetworkImage(photoUrl!)
        : const NetworkImage(
      'https://firebasestorage.googleapis.com/v0/b/hyeonproject-9cd52.firebasestorage.app/o/default_profile.png?alt=media',
    );

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(radius: 50, backgroundImage: imageProvider),
              const SizedBox(width: 20),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(username, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('#$emailTag', style: const TextStyle(fontSize: 16, color: Colors.grey)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 32),
          Expanded(
            child: ListView(
              children: [
                _buildInfoCard("작성한 여행일지", "$journalCount개", Icons.edit_location_alt),
                _buildInfoCard("공유한 항목", "$sharedCount개", Icons.share),
                _buildInfoCard(
                  "개인정보 수정",
                  "비밀번호 및 닉네임 변경",
                  Icons.settings,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const PersonalEditPage()),
                    ).then((_) {
                      _loadUserProfile();
                      _loadJournalCount();
                    });
                  },
                ),
                const SizedBox(height: 20),
                SwitchListTile(
                  title: const Text("다크 모드"),
                  value: isDarkMode,
                  secondary: const Icon(Icons.dark_mode),
                  onChanged: _toggleTheme,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard(String title, String subtitle, IconData icon, {VoidCallback? onTap}) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: Icon(icon, color: Colors.teal),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }
}
