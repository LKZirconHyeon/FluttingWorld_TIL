import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class JournalWriteScreen extends StatefulWidget {
  @override
  State<JournalWriteScreen> createState() => _JournalWriteScreenState();
}

class _JournalWriteScreenState extends State<JournalWriteScreen> {
  String? mainImagePath;
  List<String> bodyImages = [];
  bool isRange = false; // 단일/기간 선택
  DateTime? selectedStartDate;
  DateTime? selectedEndDate;

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();

  // 대표 이미지 선택
  Future<void> _pickMainImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        mainImagePath = pickedFile.path;
      });
    }
  }

  // 본문 이미지 선택
  Future<void> _pickBodyImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        bodyImages.add(pickedFile.path);
      });
    }
  }

  // 날짜 선택
  Future<void> _pickDate() async {
    if (isRange) {
      final pickedRange = await showDateRangePicker(
        context: context,
        firstDate: DateTime(2000),
        lastDate: DateTime(2100),
      );
      if (pickedRange != null) {
        setState(() {
          selectedStartDate = pickedRange.start;
          selectedEndDate = pickedRange.end;
        });
      }
    } else {
      final pickedDate = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(2000),
        lastDate: DateTime(2100),
      );
      if (pickedDate != null) {
        setState(() {
          selectedStartDate = pickedDate;
          selectedEndDate = null;
        });
      }
    }
  }

  Future<void> _saveJournal() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('로그인이 필요합니다.');

      if (_titleController.text.trim().isEmpty ||
          _contentController.text.trim().isEmpty ||
          mainImagePath == null ||
          bodyImages.isEmpty ||
          selectedStartDate == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('모든 필드를 채워주세요.')),
        );
        return;
      }

      final sanitizedEmail = user.email!.replaceAll('.', '_');
      final journalId = DateTime.now().millisecondsSinceEpoch.toString();

      await FirebaseDatabase.instance
          .ref('users/$sanitizedEmail/journals/$journalId')
          .set({
        'title': _titleController.text.trim(),
        'content': _contentController.text.trim(),
        'date': isRange
            ? '${selectedStartDate!.toIso8601String()} ~ ${selectedEndDate!.toIso8601String()}'
            : selectedStartDate!.toIso8601String(),
        'mainImageUrl': mainImagePath ?? '',
        'bodyImages': bodyImages,
      });

      // ✅ 이게 핵심!
      Navigator.pop(context, true);

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('저장 실패: $e')),
      );
    }
  }


  Future<bool> _onWillPop() async {
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('작성 취소'),
        content: const Text('작성을 취소하고 나가시겠습니까?\n(저장되지 않습니다.)'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('아니오'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('네'),
          ),
        ],
      ),
    );
    return shouldExit ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: const Color(0xFFFFF8E1),
        appBar: AppBar(
          title: const Text('여행일지 작성'),
          backgroundColor: Colors.teal,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () async {
              final shouldExit = await _onWillPop();
              if (shouldExit) {
                Navigator.of(context).pop();
              }
            },
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 대표 이미지 미리보기
              Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.5,
                  height: MediaQuery.of(context).size.width * 0.5,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    border: Border.all(color: Colors.black26),
                  ),
                  child: mainImagePath == null
                      ? const Center(child: Text('대표 이미지 미리보기'))
                      : Image.file(
                    File(mainImagePath!),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: _pickMainImage,
                child: const Text('대표 이미지 첨부'),
              ),
              if (selectedStartDate != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Text(
                    isRange
                        ? (selectedEndDate != null
                        ? '${_formatDate(selectedStartDate!)} ~ ${_formatDate(selectedEndDate!)}'
                        : _formatDate(selectedStartDate!)) // fallback 처리
                        : _formatDate(selectedStartDate!),
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                ),

              const SizedBox(height: 16),
              // 제목
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: '제목',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              // 날짜 선택
              Row(
                children: [
                  const Text('여행 날짜'),
                  const SizedBox(width: 8),
                  Switch(
                    value: isRange,
                    onChanged: (val) {
                      setState(() {
                        isRange = val;

                        selectedStartDate = null;
                        selectedEndDate = null;
                      });
                    },
                  ),

                  Text(isRange ? '기간' : '단일 날짜'),
                ],
              ),
              ElevatedButton(
                onPressed: _pickDate,
                child: const Text('날짜 선택'),
              ),
              const SizedBox(height: 16),
              // 내용
              TextField(
                controller: _contentController,
                maxLines: 8,
                decoration: const InputDecoration(
                  labelText: '내용',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              // 본문 이미지 첨부
              ElevatedButton(
                onPressed: _pickBodyImage,
                child: const Text('본문 이미지 첨부'),
              ),
              if (bodyImages.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Wrap(
                    spacing: 8,
                    children: bodyImages
                        .map((path) => Image.file(
                      File(path),
                      width: 80,
                      height: 80,
                      fit: BoxFit.cover,
                    ))
                        .toList(),
                  ),
                ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _saveJournal,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  minimumSize: const Size(double.infinity, 50),
                ),
                child: const Text('저장'),
              ),
            ],
          ),
        ),
      ),
    );
  }
  String _formatDate(DateTime date) {
    return '${date.year}년 ${date.month.toString().padLeft(2, '0')}월 ${date.day.toString().padLeft(2, '0')}일';
  }
}
