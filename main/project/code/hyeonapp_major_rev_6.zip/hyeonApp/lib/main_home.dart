import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:hyeonapp/pages/add_journal.dart';
import 'login_home.dart';
import 'register_page.dart';
import 'find_password_page.dart';
import 'pages/list_page.dart';
import 'pages/map_page.dart';
import 'pages/my_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const TravelPlannerApp());
}

class TravelPlannerApp extends StatelessWidget {
  const TravelPlannerApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '여행 플래너',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFFFF8E1),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF4DB6AC),
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          centerTitle: true,
          elevation: 0,
          toolbarHeight: 48, // AppBar 높이 줄임
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginScreen(),
        '/register': (context) => const RegisterPage(),
        '/find_password': (context) => const FindPasswordPage(),
        '/home': (context) => const HomeScreen(),
      },
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();

}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  String _userDisplay = '사용자';
  bool _refreshRequested = false;

  final List<Widget> _pages = const [
    ListPage(),
    MapPage(),
    MyPage(),
  ];

  @override
  void initState() {
    super.initState();
    _loadUserInfo();
  }

  Future<void> _loadUserInfo() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final sanitizedEmail = user.email!.replaceAll('.', '_');
      final snapshot = await FirebaseDatabase.instance
          .ref('users/$sanitizedEmail/username')
          .get();
      if (snapshot.exists) {
        setState(() {
          _userDisplay = snapshot.value.toString();
        });
      }
    }
  }

  String _getTopTitle() {
    switch (_selectedIndex) {
      case 0:
        return '$_userDisplay의 여행일지';
      case 1:
        return '지도';
      case 2:
        return '마이페이지';
      default:
        return '';
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _onAddPressed() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => JournalWriteScreen()),
    );

    if (result == true) {
      setState(() {
        _refreshRequested = true; // 다음에 ListPage 빌드 시 새로고침
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      ListPage(refreshOnReturn: _refreshRequested),
      const MapPage(),
      const MyPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(_getTopTitle()),
      ),
      body: pages[_selectedIndex],
      floatingActionButton: _selectedIndex == 0
          ? FloatingActionButton(
        onPressed: _onAddPressed,
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
      )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFFE0E0E0),
        selectedItemColor: Colors.teal[700],
        unselectedItemColor: Colors.grey[600],
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
            if (index == 0) _refreshRequested = false; // 새로고침 플래그 초기화
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.list),
            label: '리스트',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.map),
            label: '지도',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: '마이페이지',
          ),
        ],
      ),
    );
  }

}
