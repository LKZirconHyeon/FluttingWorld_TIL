import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class FindPasswordPage extends StatefulWidget {
  const FindPasswordPage({Key? key}) : super(key: key);

  @override
  State<FindPasswordPage> createState() => _FindPasswordPageState();
}

class _FindPasswordPageState extends State<FindPasswordPage> {
  final TextEditingController _emailController = TextEditingController();

  String _sanitizeEmail(String email) {
    return email.replaceAll('.', '_');
  }

  Future<String> _findPassword(String email) async {
    try {
      final sanitizedEmail = _sanitizeEmail(email);
      final ref = FirebaseDatabase.instance.ref().child('users/$sanitizedEmail/password');
      final snapshot = await ref.get();

      if (snapshot.exists) {
        return snapshot.value.toString();
      } else {
        return '비밀번호를 찾을 수 없습니다.';
      }
    } catch (e) {
      return '오류 발생: $e';
    }
  }

  void _showPassword(String password) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('비밀번호 찾기 결과'),
        content: Text(password),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('확인'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('비밀번호 찾기'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              '이메일을 입력하세요',
              style: TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(
                labelText: '이메일',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () async {
                final email = _emailController.text.trim();
                if (email.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('이메일을 입력해주세요.')),
                  );
                  return;
                }

                final password = await _findPassword(email);
                _showPassword(password);
              },
              child: const Text('비밀번호 찾기'),
            ),
          ],
        ),
      ),
    );
  }
}
