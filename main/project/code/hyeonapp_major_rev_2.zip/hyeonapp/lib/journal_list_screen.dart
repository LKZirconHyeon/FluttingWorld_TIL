import 'package:flutter/material.dart';

class JournalListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        '여행일지 목록 화면입니다.',
        style: TextStyle(fontSize: 18),
      ),
    );
  }
}
