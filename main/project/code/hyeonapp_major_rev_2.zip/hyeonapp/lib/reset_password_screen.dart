import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';

class ResetPasswordScreen extends StatelessWidget {
  final emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E1),
      appBar: AppBar(
        title: Text('비밀번호 찾기'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          children: [
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: '이메일 주소'),
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: () async {
                final inputEmail = emailController.text.trim();

                if (inputEmail.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('이메일을 입력하세요.')),
                  );
                  return;
                }

                try {
                  final snapshot = await FirebaseDatabase.instance.ref("users").get();

                  String? foundPassword;

                  for (final child in snapshot.children) {
                    final data = child.value as Map;
                    if (data['email'] == inputEmail) {
                      foundPassword = data['password'];
                      break;
                    }
                  }

                  if (foundPassword != null) {
                    showDialog(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: Text('비밀번호 찾기'),
                        content: Text('비밀번호: $foundPassword'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(),
                            child: Text('확인'),
                          ),
                        ],
                      ),
                    );
                  } else {
                    showDialog(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: Text('오류'),
                        content: Text('해당 이메일로 등록된 계정을 찾을 수 없습니다.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(),
                            child: Text('확인'),
                          ),
                        ],
                      ),
                    );
                  }
                } catch (e) {
                  showDialog(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: Text('오류 발생'),
                      content: Text('데이터를 불러오는 중 문제가 발생했습니다.'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(ctx).pop(),
                          child: Text('확인'),
                        ),
                      ],
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                minimumSize: Size(double.infinity, 50),
              ),
              child: Text('비밀번호 직접 보기'),
            ),
          ],
        ),
      ),
    );
  }
}
