import 'package:flutter/material.dart';

class JournalWriteScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        '여행일지 작성 화면입니다.',
        style: TextStyle(fontSize: 18),
      ),
    );
  }
}
