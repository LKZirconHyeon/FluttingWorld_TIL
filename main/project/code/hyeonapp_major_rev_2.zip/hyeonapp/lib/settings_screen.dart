import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'login_home.dart'; // 로그인 화면 경로에 맞게 조정

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFFF8E1),
      appBar: AppBar(
        title: Text('설정'),
        backgroundColor: Colors.teal,
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            await FirebaseAuth.instance.signOut();

            // 로그인 화면으로 이동하면서 이전 스택 모두 제거
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => LoginScreen()),
                  (route) => false,
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.teal,
            minimumSize: Size(200, 50),
          ),
          child: Text('로그아웃'),
        ),
      ),
    );
  }
}
