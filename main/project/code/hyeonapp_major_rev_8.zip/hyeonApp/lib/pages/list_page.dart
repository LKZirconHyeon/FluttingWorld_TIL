import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:intl/intl.dart';
import 'content_view.dart'; // ContentViewPage import 추가

class ListPage extends StatefulWidget {
  final bool refreshOnReturn;

  const ListPage({Key? key, this.refreshOnReturn = false}) : super(key: key);

  @override
  State<ListPage> createState() => _ListPageState();
}


class _ListPageState extends State<ListPage> {
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  List<Map<String, dynamic>> _journals = [];

  @override
  void initState() {
    super.initState();
    _fetchJournals();
  }

  @override
  void didUpdateWidget(covariant ListPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.refreshOnReturn && !oldWidget.refreshOnReturn) {
      _fetchJournals();
    }
  }

  // ✅ 날짜 포맷 유틸 함수는 여기 위치해야 효율적입니다
  String formatDateRange(String rawDate) {
    if (rawDate.contains('~')) {
      final parts = rawDate.split('~');
      final start = DateTime.tryParse(parts[0].trim());
      final end = DateTime.tryParse(parts[1].trim());

      if (start != null && end != null) {
        return '${DateFormat('yyyy년 MM월 dd일').format(start)} ~ ${DateFormat('yyyy년 MM월 dd일').format(end)}';
      }
    } else {
      final date = DateTime.tryParse(rawDate);
      if (date != null) {
        return DateFormat('yyyy년 MM월 dd일').format(date);
      }
    }
    return '날짜 오류';
  }

  Future<void> _fetchJournals() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final snapshot = await _database.child('users/$sanitizedEmail/journals').get();

    List<Map<String, dynamic>> temp = [];
    if (snapshot.exists) {
      final data = snapshot.value as Map<dynamic, dynamic>;
      data.forEach((key, value) {
        final item = Map<String, dynamic>.from(value);
        item['journalId'] = key;
        temp.add(item);
      });
    }

    if (!mounted) return;

    setState(() {
      _journals = temp;
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E1),
      body: _journals.isEmpty
          ? const Center(child: Text('저장된 여행일지가 없습니다.'))
          : ListView.builder(
        itemCount: _journals.length,
        itemBuilder: (context, index) {
          final journal = _journals[index];
          final dateString = journal['date'] ?? '';
          final formattedDate = formatDateRange(dateString);
          final imagePath = journal['mainImageUrl'];

          return GestureDetector(
            onTap: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ContentViewPage(
                    journal: journal,
                    journalId: journal['journalId'],
                  ),
                ),
              );
              if (result == true) {
                _fetchJournals();
              }
            },
            child: Card(
              margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    // 왼쪽: 제목과 날짜
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            journal['title'] ?? '제목 없음',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            formattedDate,
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                    // 오른쪽: 이미지
                    if (imagePath != null && imagePath.isNotEmpty)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.file(
                          File(imagePath),
                          width: 60,
                          height: 60,
                          fit: BoxFit.cover,
                        ),
                      )
                    else
                      Container(
                        width: 60,
                        height: 60,
                        color: Colors.grey[300],
                        child: const Icon(Icons.image, color: Colors.grey),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

