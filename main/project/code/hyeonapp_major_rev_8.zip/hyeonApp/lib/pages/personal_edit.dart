import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class PersonalEditPage extends StatefulWidget {
  const PersonalEditPage({Key? key}) : super(key: key);

  @override
  State<PersonalEditPage> createState() => _PersonalEditPageState();
}

class _PersonalEditPageState extends State<PersonalEditPage> {
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();

  String emailTag = '';
  String? photoUrl;
  File? _newImageFile;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final snapshot = await FirebaseDatabase.instance
        .ref('users/$sanitizedEmail')
        .get();

    setState(() {
      _nameController.text =
          snapshot.child("username").value?.toString() ?? '';
      _passwordController.text =
          snapshot.child("password").value?.toString() ?? '';
      emailTag = user.email!.split('@')[0];
      photoUrl = snapshot.child("photoUrl").value?.toString();
    });
  }

  Future<void> _pickProfileImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);

    if (picked != null) {
      setState(() {
        _newImageFile = File(picked.path);
      });
    }
  }

  Future<void> _saveChanges() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final ref = FirebaseDatabase.instance.ref('users/$sanitizedEmail');

    String? uploadedImageUrl = photoUrl;
    final newPassword = _passwordController.text.trim();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      // 1️⃣ 프로필 이미지 업로드
      if (_newImageFile != null) {
        final storageRef = FirebaseStorage.instance
            .ref()
            .child('profile_images/$sanitizedEmail.png');

        final uploadTask = storageRef.putFile(_newImageFile!);
        await uploadTask.timeout(
          const Duration(seconds: 15),
          onTimeout: () => throw Exception("⏰ 이미지 업로드 시간 초과"),
        );

        uploadedImageUrl = await storageRef.getDownloadURL();
      }

      // 2️⃣ 비밀번호 변경 적용 (Firebase Auth + RTDB 동시)
      if (newPassword.isNotEmpty) {
        // reauthenticate first (필수)
        final cred = EmailAuthProvider.credential(
          email: user.email!,
          password: newPassword, // 예제용 - 실제 앱은 '현재 비밀번호' 입력받아야 함
        );

        try {
          await user.reauthenticateWithCredential(cred);
        } catch (_) {
          // 기존 비밀번호가 아니므로 재인증 없이 처리 진행 (과제 목적)
          // 실서비스는 반드시 현재 비밀번호로 인증 필요
        }

        await user.updatePassword(newPassword);
      }

      // 3️⃣ RTDB 업데이트
      await ref.update({
        "username": _nameController.text.trim(),
        "password": newPassword, // 실제론 저장하지 않음
        "photoUrl": uploadedImageUrl,
      });

      await FirebaseAuth.instance.currentUser?.reload(); // 최신화

      setState(() {
        _newImageFile = null;
        photoUrl = uploadedImageUrl;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("정보가 저장되었습니다")),
      );

      Future.delayed(const Duration(seconds: 1), () {
        Navigator.pop(context);
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("저장 실패: $e")),
      );
    } finally {
      if (Navigator.canPop(context)) {
        Navigator.pop(context); // 로딩 종료
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final defaultProfileUrl =
        'https://firebasestorage.googleapis.com/v0/b/hyeonproject-9cd52.firebasestorage.app/o/default_profile.png?alt=media';

    return Scaffold(
      appBar: AppBar(title: const Text('개인정보 수정')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Center(
              child: GestureDetector(
                onTap: _pickProfileImage,
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: _newImageFile != null
                      ? FileImage(_newImageFile!)
                      : (photoUrl != null && photoUrl!.isNotEmpty
                      ? NetworkImage(photoUrl!)
                      : NetworkImage(defaultProfileUrl)) as ImageProvider,
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: "닉네임",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              readOnly: true,
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("계정 태그는 변경할 수 없습니다.")),
                );
              },
              decoration: InputDecoration(
                labelText: "계정 태그",
                hintText: "#$emailTag",
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: "비밀번호",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _saveChanges,
              icon: const Icon(Icons.save),
              label: const Text("저장하기"),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
