import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:hyeonapp/pages/personal_edit.dart';

class MyPage extends StatefulWidget {
  const MyPage({Key? key}) : super(key: key);

  @override
  State<MyPage> createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  String username = '';
  String emailTag = '';
  String? photoUrl;
  int journalCount = 0; // 여행일지 개수

  @override
  void initState() {
    super.initState();
    _loadUserProfile();
    _loadJournalCount(); // 여행일지 수 로드
  }

  Future<void> _loadUserProfile() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');
    final snapshot = await FirebaseDatabase.instance
        .ref('users/$sanitizedEmail')
        .get();

    setState(() {
      username = snapshot.child('username').value?.toString() ?? '알 수 없음';
      photoUrl = snapshot.child('photoUrl').value?.toString();
      emailTag = user.email!.split('@')[0];
    });
  }

  Future<void> _loadJournalCount() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final sanitizedEmail = user.email!.replaceAll('.', '_');

    final snapshot = await FirebaseDatabase.instance
        .ref('users/$sanitizedEmail/journals')
        .get();

    setState(() {
      journalCount = snapshot.exists ? snapshot.children.length : 0;
    });
  }


  @override
  Widget build(BuildContext context) {
    final ImageProvider imageProvider;
    if (photoUrl != null &&
        photoUrl!.isNotEmpty &&
        (photoUrl!.startsWith('http') || photoUrl!.startsWith('https'))) {
      imageProvider = NetworkImage(photoUrl!);
    } else {
      imageProvider = const NetworkImage(
        'https://firebasestorage.googleapis.com/v0/b/hyeonproject-9cd52.firebasestorage.app/o/default_profile.png?alt=media',
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // 🔼 상단: 프로필 정보
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 50,
                backgroundImage: imageProvider,
              ),
              const SizedBox(width: 20),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    username,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '#$emailTag',
                    style: const TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 32),

          // 🔽 하단 카드 메뉴들
          Expanded(
            child: ListView(
              children: [
                _buildInfoCard("작성한 여행일지", "$journalCount개", Icons.edit_location_alt),
                _buildInfoCard("공유한 항목", "2개", Icons.share), // 공유 항목은 나중에 로직 추가 가능
                _buildInfoCard(
                  "개인정보 수정",
                  "비밀번호 및 닉네임 변경",
                  Icons.settings,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const PersonalEditPage(),
                      ),
                    ).then((_) {
                      _loadUserProfile();     // 수정 후 사용자 정보 새로고침
                      _loadJournalCount();    // 여행일지 수 새로고침
                    });
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ✨ 카드 UI 위젯 함수
  Widget _buildInfoCard(String title, String subtitle, IconData icon, {VoidCallback? onTap}) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: Icon(icon, color: Colors.teal),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }
}
