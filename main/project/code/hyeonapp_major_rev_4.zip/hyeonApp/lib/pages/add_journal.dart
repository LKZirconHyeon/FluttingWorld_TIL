import 'package:flutter/material.dart';

class JournalWriteScreen extends StatefulWidget {
  @override
  State<JournalWriteScreen> createState() => _JournalWriteScreenState();
}

class _JournalWriteScreenState extends State<JournalWriteScreen> {
  String? mainImagePath;
  bool isRange = false; // 단일/기간 선택

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFFF8E1),
      appBar: AppBar(
        title: Text('여행일지 작성'),
        backgroundColor: Colors.teal,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 대표 이미지 미리보기 (정사각형)
            Center(
              child: Container(
                width: MediaQuery.of(context).size.width * 0.6, // 화면의 60%만 사용
                height: MediaQuery.of(context).size.width * 0.6, // 정사각형
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  border: Border.all(color: Colors.black26),
                ),
                child: mainImagePath == null
                    ? Center(child: Text('대표 이미지 미리보기'))
                    : Image.network(mainImagePath!, fit: BoxFit.cover),
              ),
            ),
            SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                // TODO: 대표 이미지 첨부 기능
              },
              child: Text('대표 이미지 첨부'),
            ),
            SizedBox(height: 16),
            // 제목
            TextField(
              decoration: InputDecoration(
                labelText: '제목',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            // 날짜 선택
            Row(
              children: [
                Text('여행 날짜'),
                SizedBox(width: 8),
                Switch(
                  value: isRange,
                  onChanged: (val) {
                    setState(() {
                      isRange = val;
                    });
                  },
                ),
                Text(isRange ? '기간' : '단일 날짜'),
              ],
            ),
            ElevatedButton(
              onPressed: () {
                // TODO: 날짜 선택
              },
              child: Text('날짜 선택'),
            ),
            SizedBox(height: 16),
            // 내용
            TextField(
              maxLines: 8,
              decoration: InputDecoration(
                labelText: '내용',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            // 본문 이미지 첨부
            ElevatedButton(
              onPressed: () {
                // TODO: 본문 이미지 첨부
              },
              child: Text('본문 이미지 첨부'),
            ),
            SizedBox(height: 24),
            // 저장 버튼
            ElevatedButton(
              onPressed: () {
                // TODO: 저장
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                minimumSize: Size(double.infinity, 50),
              ),
              child: Text('저장'),
            ),
          ],
        ),
      ),
    );
  }
}
